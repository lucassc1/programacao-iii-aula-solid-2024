package br.edu.umfg.lsp.refatorado;

public class AlunoPresencialRefatorado extends AbstractAluno{
    public AlunoPresencialRefatorado(String ra, String nome, Double notaFinal) {
        super(ra, nome, notaFinal);
    }
}
