package br.edu.umfg.srp.legado;

public enum TipoFuncionario {
    Estagiario,
    Vendedor,
}
