package br.edu.umfg.isp.refatorado;

public interface IContaInvestimento {
    void investir(Double valor);
}
