package br.edu.umfg.ocp.refatorado;

public enum TipoEstado {
    Parana,
    SaoPaulo,
    SantaCatarina,
}