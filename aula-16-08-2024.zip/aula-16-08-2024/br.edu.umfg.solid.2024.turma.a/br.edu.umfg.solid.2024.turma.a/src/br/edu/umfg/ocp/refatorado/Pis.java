package br.edu.umfg.ocp.refatorado;

public class Pis extends AbstractImpostoFederal{
    public Pis() {
        super("PIS", 1.65);
    }
}
