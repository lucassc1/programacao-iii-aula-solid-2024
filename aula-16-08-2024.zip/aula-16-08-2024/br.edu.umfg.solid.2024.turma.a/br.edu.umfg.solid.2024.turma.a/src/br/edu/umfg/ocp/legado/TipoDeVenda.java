package br.edu.umfg.ocp.legado;

public enum TipoDeVenda {
    Parana,
    SaoPaulo,
    SantaCatarina,
}
